﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PipeMovement : MonoBehaviour
{
    public float speed;
    private float leftEdge;
    // Start is called before the first frame update
    void Start()
    {
        //screen space to world space conversion
        //1 offset so you don't see pipes disappear before destroying
        leftEdge = Camera.main.ScreenToWorldPoint(Vector3.zero).x - 1f; 
    }

    // Update is called once per frame
    void Update()
    {
        transform.position += Vector3.left * speed * Time.deltaTime;
        if (transform.position.x < leftEdge)
        {
            Destroy(gameObject);
        }
    }

}
