﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class Movement : MonoBehaviour
{
    //parameters
    public float gravity = -9.8f;
    public float flapStrength;
    //Privates
    private SpriteRenderer spriteRenderer;
    private Vector3 flying;

    private string sceneName;

    // Start is called before the first frame update
    void Start()
    {
        Scene currentScene = SceneManager.GetActiveScene();
        sceneName = currentScene.name;

    }

    // Update is called once per graphical frame
    private void Update()
    {
            
    }

    private void FixedUpdate()
    {
        //bird flap up with space
        if (Input.GetKey(KeyCode.Space))
        {
            flying = Vector3.up * flapStrength;
            transform.position += flying;

        }
        else
        //bird fall down with no input
        //two time.deltaTime s because gravity is ms^2
        flying.y += gravity * Time.deltaTime;
        transform.position += flying * Time.deltaTime;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        //without conditionals faby no longer collides
        if (sceneName == "Flappy_Bird_Problem")
        {
            if (collision.gameObject.tag == "Lose")
            {
                FindObjectOfType<GameManager>().GameOver();
            }
            else if (collision.gameObject.tag == "Score")
            {
                FindObjectOfType<GameManager>().Score();
            }
        }
        else if (sceneName == "Solution")
        {
            if (collision.gameObject.tag == "Lose")
            {
                FindObjectOfType<GameManager>().GameOver();
            }
            else if (collision.gameObject.tag == "Score")
            {
                FindObjectOfType<GameManager>().Score();
            }
        }
    }
}
