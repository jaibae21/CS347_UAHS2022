﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine;

public class SceneControl : MonoBehaviour
{
    public string scene1Name = "Flappy_Bird_Problem";
    public string scene2Name = "Solution";

    private string targetSceneName;

    // Start is called before the first frame update
    void Start()
    {
        var currentSceneName = SceneManager.GetActiveScene().name;
        targetSceneName = (currentSceneName == scene1Name) ? scene2Name : scene1Name;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Z))
        {
            SceneManager.LoadSceneAsync(targetSceneName);
        }
    }
}
