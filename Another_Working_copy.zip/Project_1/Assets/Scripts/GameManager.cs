﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    private int score;
    public  Movement player;
    public Text scoreText;
    //UI images
    public GameObject playButton;
    public GameObject gameOver;
    public GameObject title;
    public GameObject tap;
    [SerializeField]
    private Image lives;
    //scene swapping
    private string sceneName;
    // Start is called before the first frame update
    void Start()
    {
        Scene currentScene = SceneManager.GetActiveScene();
        sceneName = currentScene.name;
        if (sceneName == "Flappy_Bird_Problem")
        {
            //run problem stuff
            title.SetActive(true);
            gameOver.SetActive(false);
            tap.SetActive(true);
            //gonna make the playbutton be what resets the scene
            playButton.SetActive(false);   
            Application.targetFrameRate = 60;
            Pause();
        }
        //needs heart UI added
        else if (sceneName == "Solution")
        {
            title.SetActive(true);
            gameOver.SetActive(false);
            tap.SetActive(true);
            //gonna make the playbutton be what resets the scene
            playButton.SetActive(false);
            Application.targetFrameRate = 60;
            Pause();
        }
    }
    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.H))
        {
            Play();
        }
        //Swap scenes with E
        if (Input.GetKeyDown(KeyCode.E) && (sceneName == "Flappy_Bird_Problem"))
        {
            SceneManager.LoadScene("Solution");
        }
        else if (Input.GetKeyDown(KeyCode.E) && (sceneName == "Solution"))
        {
            SceneManager.LoadScene("Flappy_Bird_Problem");
        }
    }
    public void Play()
    {
        if (sceneName == "Flappy_Bird_Problem")
        {
            score = 0;
            scoreText.text = score.ToString();
            playButton.SetActive(false);
            title.SetActive(false);
            gameOver.SetActive(false);
            tap.SetActive(false);
            Time.timeScale = 1f;
            player.enabled = true;
        }
        score = 0;
        scoreText.text = score.ToString();
        playButton.SetActive(false);
        title.SetActive(false);
        gameOver.SetActive(false);
        tap.SetActive(false);
        Time.timeScale = 1f;
        player.enabled = true;
 
    }
    //Pause should not change between scenes
    public void Pause()
    {
        Time.timeScale = 0f;
        //disable player
        player.enabled = false;
    }
    //Score should not change between scenes
    public void Score()
    {
        score++;
        scoreText.text = score.ToString();
    }
    public void GameOver()
    {
        if (sceneName == "Flappy_Bird_Problem")
        {
            gameOver.SetActive(true);
            playButton.SetActive(true);
            Pause();
        }
    }
}
