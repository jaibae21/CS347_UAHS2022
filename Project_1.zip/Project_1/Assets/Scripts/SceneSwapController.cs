﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneSwapController : MonoBehaviour
{
    public string scene1Name = "Problem";
    public string scene2Name = "Solution";

    private string targetSceneName; 

    // Start is called before the first frame update
    void Start()
    {
        var currentSceneName = SceneManager.GetActiveScene().name;
        targetSceneName = (currentSceneName == scene1Name) ? scene2Name : scene1Name; 
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Z))
        {
            SceneManager.LoadSceneAsync(targetSceneName); 
        }
    }
}
