﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public enum wingPosition { UP, DOWN, MIDDLE };

    //parameters
    public float gravity = -9.8f;
    public float flapStrength;
    //Privates
    private SpriteRenderer spriteRenderer;
    private Vector3 flying;

    //Hidden publics

    // Start is called before the first frame update
    void Start()
    {


    }

    // Update is called once per graphical frame
    private void Update()
    {
            
    }
    
    private void OnEnable()
    {
        Vector3 position = transform.position;
        position.y = 0;
        transform.position = position;
        flying = Vector3.zero;
    }
    
    private void FixedUpdate()
    {
        //bird flap up with space
        if (Input.GetKey(KeyCode.Space))
        {
            flying = Vector3.up * flapStrength;
            transform.position += flying;

        }
        else
        //bird fall down with no input
        //two time.deltaTime s because gravity is ms^2
        flying.y += gravity * Time.deltaTime;
        transform.position += flying * Time.deltaTime;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Lose")
        {
            FindObjectOfType<GameManager>().GameOver();
        }
        else if (collision.gameObject.tag == "Score")
        {
            FindObjectOfType<GameManager>().Score();
        }
    }
}
