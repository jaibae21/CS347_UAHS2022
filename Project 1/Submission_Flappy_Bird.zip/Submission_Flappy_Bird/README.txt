Solution Implemented: Having a 3 health life system. However, hitting the ground is immediate game over. Lives only apply if you hit pipes. 

Controls:
	Space Bar: jump/flap
	E: switch scenes
	H: Start Game
	Click Start: Restart Game
	
Known Bug: 
	If a user decides to press H instead of clicking to restart the game the game will pick up where it left off which also means if Faby fell on the ground he would be absent from the game. 