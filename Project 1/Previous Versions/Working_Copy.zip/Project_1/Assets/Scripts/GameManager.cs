﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    private int score;
    public  Movement player;
    public Text scoreText;
    //UI images
    public GameObject playButton;
    public GameObject gameOver;
    public GameObject title;
    public GameObject tap;
    // Start is called before the first frame update
    void Start()
    {
        title.SetActive(true);
        gameOver.SetActive(false);
        tap.SetActive(true);
        //gonna make the playbutton be what resets the scene
        playButton.SetActive(false);   
        Application.targetFrameRate = 60;
        Pause();

    }
    public void Update()
    {
        if (Input.GetKeyDown(KeyCode.H))
        {
            Play();
        }
    }
    public void Play()
    {
        score = 0;
        scoreText.text = score.ToString();
        playButton.SetActive(false);
        title.SetActive(false);
        gameOver.SetActive(false);
        tap.SetActive(false);
        Time.timeScale = 1f;
        player.enabled = true;
        /*  currently breaking game
        PipeSpawner[] pipes = FindObjectsOfType<PipeSpawner>();
        for(int i = 0; i < pipes.Length; i++)
        {
            //destroys entire gameobject instead of just 1 compoennt
            Destroy(pipes[i].gameObject);
        }
        */
    }
    public void Pause()
    {
        Time.timeScale = 0f;
        //disable player
        player.enabled = false;
    }
    public void Score()
    {
        score++;
        scoreText.text = score.ToString();
    }
    public void GameOver()
    {
        gameOver.SetActive(true);
        playButton.SetActive(true);
        Pause();
    }
}
